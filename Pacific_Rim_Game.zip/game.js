
// Game Setup
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
canvas.width = 800;
canvas.height = 400;

// Player (Jaeger) Object
const player = {
    x: 100,
    y: 250,
    width: 60,
    height: 100,
    speed: 5,
    dx: 0,
    attack: false,
    specialAttack: false,
    specialCooldown: 0
};

// Kaiju Enemy
const kaiju = {
    x: 600,
    y: 250,
    width: 80,
    height: 120,
    health: 100
};

// Mission System
let mission = {
    type: "Defeat the Kaiju",
    completed: false,
    timer: 60 // seconds
};

// Timer Countdown
setInterval(() => {
    if (mission.timer > 0 && !mission.completed) {
        mission.timer--;
    }
    if (player.specialCooldown > 0) {
        player.specialCooldown--;
    }
}, 1000);

// Controls
document.addEventListener("keydown", (e) => {
    if (e.key === "ArrowRight") player.dx = player.speed;
    if (e.key === "ArrowLeft") player.dx = -player.speed;
    if (e.key === " ") player.attack = true;
    if (e.key === "Enter" && player.specialCooldown === 0) {
        player.specialAttack = true;
        player.specialCooldown = 5; // Cooldown for 5 seconds
    }
});

document.addEventListener("keyup", (e) => {
    if (e.key === "ArrowRight" || e.key === "ArrowLeft") player.dx = 0;
    if (e.key === " ") player.attack = false;
    if (e.key === "Enter") player.specialAttack = false;
});

// Mobile Touch Controls
function createButton(text, x, y, action) {
    let btn = document.createElement("button");
    btn.innerHTML = text;
    btn.style.position = "absolute";
    btn.style.left = x + "px";
    btn.style.top = y + "px";
    btn.style.width = "80px";
    btn.style.height = "50px";
    btn.style.fontSize = "16px";
    btn.style.background = "#444";
    btn.style.color = "white";
    btn.style.border = "none";
    btn.style.borderRadius = "5px";
    btn.style.zIndex = "100";
    btn.addEventListener("touchstart", action);
    document.body.appendChild(btn);
}

// Movement Buttons
createButton("←", 30, 330, () => { player.dx = -player.speed; });
createButton("→", 120, 330, () => { player.dx = player.speed; });
createButton("Stop", 75, 380, () => { player.dx = 0; });

// Attack Buttons
createButton("Punch", 600, 330, () => { player.attack = true; setTimeout(() => player.attack = false, 200); });
createButton("Special", 690, 330, () => {
    if (player.specialCooldown === 0) {
        player.specialAttack = true;
        player.specialCooldown = 5;
        setTimeout(() => player.specialAttack = false, 200);
    }
});

// Update Game State
function update() {
    player.x += player.dx;

    // Collision Detection for Attack
    if (player.attack && Math.abs(player.x - kaiju.x) < 70) {
        kaiju.health -= 5;
        console.log("Kaiju Hit! Health:", kaiju.health);
    }

    // Special Attack Effect
    if (player.specialAttack && Math.abs(player.x - kaiju.x) < 100) {
        kaiju.health -= 20; // Heavy Damage
        console.log("Special Attack! Kaiju Health:", kaiju.health);
        player.specialAttack = false; // Reset after one hit
    }

    // Mission Completion Check
    if (kaiju.health <= 0) {
        mission.completed = true;
    }

    draw();
    requestAnimationFrame(update);
}

// Draw Function
function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw Player
    ctx.fillStyle = "blue";
    ctx.fillRect(player.x, player.y, player.width, player.height);

    // Special Attack Effect
    if (player.specialAttack) {
        ctx.fillStyle = "cyan";
        ctx.fillRect(player.x - 10, player.y, player.width + 20, player.height);
    }

    // Draw Kaiju
    if (kaiju.health > 0) {
        ctx.fillStyle = "red";
        ctx.fillRect(kaiju.x, kaiju.y, kaiju.width, kaiju.height);
    }

    // Draw Mission Info
    ctx.fillStyle = "white";
    ctx.font = "20px Arial";
    ctx.fillText("Mission: " + mission.type, 20, 30);
    ctx.fillText("Time Left: " + mission.timer, 20, 60);

    // Draw Special Attack Cooldown
    ctx.fillText("Special Cooldown: " + player.specialCooldown, 20, 90);

    // Draw Kaiju Health
    ctx.fillText("Kaiju HP: " + kaiju.health, kaiju.x, kaiju.y - 10);

    // Mission Completed Message
    if (mission.completed) {
        ctx.fillStyle = "yellow";
        ctx.font = "30px Arial";
        ctx.fillText("MISSION COMPLETE!", canvas.width / 2 - 100, canvas.height / 2);
    }
}

// Start Game Loop
update();
